def PatternCheck(strings,pattrens):
    strlen=len(strings)
    ptrnlen=len(patterns)
    
    if strlen!=ptrnlen:
        print("False")
        return False    
    for i in range(strlen):
        j=i+1
        for j in range(strlen):
            if (strings[i]==strings[j])!=(patterns[i]==patterns[j]):
                print("False")
                return False
    print("True")
    return True

strings=[input("Enter the strings: ")]
patterns=[input("Enter the pattern: ")]


PatternCheck(strings,patterns)









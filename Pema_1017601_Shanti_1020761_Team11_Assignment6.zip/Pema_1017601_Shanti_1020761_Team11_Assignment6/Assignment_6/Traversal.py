class Node(object):
    def __init__(self, data=None, left=None, right=None):
        self.data = data
        self.left = left
        self.right = right

def buildTree(i):
    if i < len(values):
        return Node(values[i], left=buildTree((i+1)*2-1), right=buildTree((i+1)*2))

values = [1,0,4,3,1]
tree = buildTree(0)
allpaths = []

def inorder(node):
    if node is None:
        return

    for v in inorder(node.left):
        yield v
    yield node.data
    for v in inorder(node.right):
        yield v


# function to print all path from root
# to leaf in binary tree
def printPaths(root):
    # list to store path
    path = []
    printPathsRec(root, path, 0)

# Helper function to print path from root
# to leaf in binary tree
def printPathsRec(root, path, pathLen):

    # Base condition - if binary tree is
    # empty return
    if root is None:
        return

    # add current root's data into
    # path_ar list

    # if length of list is gre
    if(len(path) > pathLen):
        path[pathLen] = root.data
    else:
        path.append(root.data)


    # increment pathLen by 1
    pathLen = pathLen + 1

    if root.left is None and root.right is None:

        # leaf node then print the list
        paLi=printArray(path, pathLen)

    else:
        # try for left and right subtree
        printPathsRec(root.left, path, pathLen)
        printPathsRec(root.right, path, pathLen)



# Helper function to print list in which
# root-to-leaf path is stored
l=[]
def printArray(ints, len):
    li=[]
    print(end='     ')
    for i in ints[0 : len]:
        print(i,end="")
        li.append(i)
    print()

    #print(li)
    k=[str(x) for x in li]
    #print(k)
    a=int("".join(k))
    #print(a)
    l.append(a)
    #print(l)
    return l


print("Inorder traversal: ", end='')
print(list(inorder(tree)))
print("Paths: ")
printPaths(tree)
print()
print("Sum of all paths: ", end='')
for i in range(len(l)):

    endl = ''
    if i < len(l)-1:
        endl = ' + '
    print(l[i], end=endl)
print(" =", sum(l))
